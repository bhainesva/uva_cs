I don't think you should have to do anything special to run this. It's python 2.
