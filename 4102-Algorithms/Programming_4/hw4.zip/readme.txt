There shouldn't be anything special required to run the code. It's python 2. 
