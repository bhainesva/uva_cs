No special steps should be required to run the program.
